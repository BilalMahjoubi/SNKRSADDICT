<?php
include_once('Fonctions.php');
$link = connectDB();

$user = $_POST['user'];
$nom = $_POST['nameD'];
$mdp = $_POST['mdp'];

$sql = "INSERT INTO `Login`(`user`, `nomDiscord`, `mdp`) VALUES ('".addslashes($user)."', '".addslashes($nom)."', '".addslashes($mdp)."')";
$result = $link->query($sql);

$monfichier = fopen('BOT EXPORT/bot.csv', 'c+');

// Tronquer le fichier à la taille zéro.
// Est équivalant à écraser le fichier
ftruncate($monfichier,0);

if($monfichier!=false)
{
    $stmt = $link->prepare("SELECT * FROM Login");
    $stmt->execute();
    $header = true;
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if ($header) {
            fputcsv($monfichier, array_keys($row));
            $header = false;
        }
        fputcsv($monfichier, $row);
    }
    fclose($monfichier);
}else{
    print "Impossible d'ouvrir ou de créer le fichier.";
}

echo "OK";
