<?php
include_once('Fonctions.php');
$link = connectDB();

$user = $_POST['user'];
$nom = $_POST['nameD'];
$mdp = $_POST['mdp'];

$sql = "INSERT INTO `Login`(`user`, `nomDiscord`, `mdp`) VALUES ('".addslashes($user)."', '".addslashes($nom)."', '".addslashes($mdp)."')";
$result = $link->query($sql);

echo "OK";
